<template>
    <div class="h-full flex flex-col justify-between z-[2]">
        <PhoneScreenTimer />
        <PhoneScreenFooter />
    </div>
</template>

<script setup></script>

<style lang="scss"></style>
